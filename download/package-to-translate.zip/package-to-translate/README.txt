The file "language.txt" is in PT-BR language, take this file open it with a text editor and translate only the parts 
that are within the area "=" to ":/:".

After translating save on keeping the file name, then simply compress in '.zip' and send to email:
supermockmensagem@gmail.com

With the following information:

Subject: TRANSLATION MCS [YOUR LANGUAGE HERE]
Email body:

Name: [WHO HAS TRANSLATED] (optional)
Date: [DATE OF TRANSLATE]
Additional information: [IS AT YOUR OWN ANY NOTE] (optional)

[DO NOT FORGET TO ADD '.ZIP' TRANSLATION!]

Sorry the translation was done by Google Translate.

Best regards, SuperMock.